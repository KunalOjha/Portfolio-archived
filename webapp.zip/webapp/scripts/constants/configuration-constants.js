/**
* Defines application-wide key value pairs 
*/

Application.Constants.constant('configurationConstants', {

    ITEMS_URL : 'data/items.json'

});